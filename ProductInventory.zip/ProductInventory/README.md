# Product Inventory System (ASP.NET MVC + EF Core, N-tier)

## Run
```
dotnet new sln -n ProductInventory
dotnet sln add ProductInventory.DAL ProductInventory.BLL ProductInventory.PL
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate -p ProductInventory.DAL -s ProductInventory.PL
dotnet ef database update -p ProductInventory.DAL -s ProductInventory.PL
dotnet run --project ProductInventory.PL
```
(Edit the connection string in ProductInventory.PL/appsettings.json if needed.)

## Architecture
- **DAL**: `AppDbContext`, `Product` entity, `ProductConfiguration` (Fluent API), `IProductRepository`/`ProductRepository` (non-generic), migrations.
- **BLL**: `ProductService` (business rules), ViewModels with validation.
- **PL**: MVC controller + views. The controller depends only on `IProductService`.

## Repository + DI
`IProductRepository` -> `ProductRepository` and `IProductService` -> `ProductService`, `AppDbContext`
are registered in `Program.cs` (scoped). Dependencies are constructor-injected:
Controller -> Service -> Repository -> DbContext.

## CRUD
- Create: `ProductsController.Create` -> `ProductService.CreateAsync` -> `repo.AddAsync` + `SaveChanges`.
- Read: `Index` (paged list with search/filter/low-stock) and `Details` (by id).
- Update: `Edit` -> `UpdateAsync`. 
- Delete: soft delete (`IsActive = false`); inactive products are hidden from the list.
- Restock: separate action, quantity must be > 0.

## Validation
| Rule | Where |
|---|---|
| Name required/max 100, SKU required/max 20, Description max 500, Price > 0, Stock >= 0 | DataAnnotations on `ProductViewModel` (server + client via unobtrusive) |
| ExpiryDate not in past | `ProductViewModel.Validate` (server) + JS in `_ProductForm` (client) |
| Grocery => ExpiryDate required | `ProductViewModel.Validate` (server) + JS in `_ProductForm` (client) |
| SKU unique (clear error) | `ProductService` checks `SkuExistsAsync` + unique DB index + catches `DbUpdateException` |
| ID must exist (else NotFound) | Service returns `NotFound`, controller returns `NotFound()` |
| DB limits, precision (18,2), Category as string, defaults | `ProductConfiguration` |
