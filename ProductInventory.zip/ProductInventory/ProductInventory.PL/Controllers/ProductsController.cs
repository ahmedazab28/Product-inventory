using Microsoft.AspNetCore.Mvc;
using ProductInventory.BLL.Services;
using ProductInventory.BLL.ViewModels;
using ProductInventory.DAL.Entities;
namespace ProductInventory.PL.Controllers;

// Talks to the BLL only (IProductService)
public class ProductsController : Controller
{
    private readonly IProductService _service;
    public ProductsController(IProductService service) => _service = service;

    public async Task<IActionResult> Index(string? search, ProductCategory? category, bool lowStock = false, int page = 1)
        => View(await _service.GetListAsync(search, category, lowStock, page, 5));

    public async Task<IActionResult> Details(int id)
    {
        var vm = await _service.GetByIdAsync(id);
        return vm is null ? NotFound() : View(vm);
    }

    public IActionResult Create() => View(new ProductViewModel());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(ProductViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var r = await _service.CreateAsync(vm);
        if (!r.Success) { AddErrors(r); return View(vm); }
        TempData["Success"] = "Product created successfully";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var vm = await _service.GetByIdAsync(id);
        return vm is null ? NotFound() : View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, ProductViewModel vm)
    {
        if (id != vm.Id) return NotFound();
        if (!ModelState.IsValid) return View(vm);
        var r = await _service.UpdateAsync(vm);
        if (r.NotFound) return NotFound();
        if (!r.Success) { AddErrors(r); return View(vm); }
        TempData["Success"] = "Product updated successfully";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Delete(int id)
    {
        var vm = await _service.GetByIdAsync(id);
        return vm is null ? NotFound() : View(vm);
    }

    [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var r = await _service.DeleteAsync(id);
        if (r.NotFound) return NotFound();
        TempData["Success"] = "Product deleted";
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Restock(int id)
    {
        var vm = await _service.GetRestockAsync(id);
        return vm is null ? NotFound() : View(vm);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Restock(RestockViewModel vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var r = await _service.RestockAsync(vm);
        if (r.NotFound) return NotFound();
        if (!r.Success) { AddErrors(r); return View(vm); }
        TempData["Success"] = "Stock updated";
        return RedirectToAction(nameof(Index));
    }

    private void AddErrors(ServiceResult r)
    { foreach (var (k, m) in r.Errors) ModelState.AddModelError(k, m); }
}
