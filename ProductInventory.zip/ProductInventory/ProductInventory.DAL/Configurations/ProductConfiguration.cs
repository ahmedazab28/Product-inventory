using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ProductInventory.DAL.Entities;
namespace ProductInventory.DAL.Configurations;
public class ProductConfiguration : IEntityTypeConfiguration<Product>
{
    public void Configure(EntityTypeBuilder<Product> b)
    {
        b.HasKey(p => p.Id);
        b.Property(p => p.Name).IsRequired().HasMaxLength(100);
        b.Property(p => p.Sku).IsRequired().HasMaxLength(20);
        b.Property(p => p.Description).HasMaxLength(500);
        b.Property(p => p.Price).HasPrecision(18, 2);
        b.HasIndex(p => p.Sku).IsUnique();
        b.Property(p => p.Category).HasConversion<string>().HasMaxLength(30);
        b.Property(p => p.CreatedAt).HasDefaultValueSql("GETUTCDATE()");
        b.Property(p => p.IsActive).HasDefaultValue(true);
    }
}
