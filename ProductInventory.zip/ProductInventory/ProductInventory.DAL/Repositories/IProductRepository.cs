using ProductInventory.DAL.Entities;
namespace ProductInventory.DAL.Repositories;
public interface IProductRepository
{
    Task<(List<Product> Items, int Total)> GetPagedAsync(string? search, ProductCategory? category, int? stockBelow, int page, int pageSize);
    Task<Product?> GetByIdAsync(int id);
    Task<bool> SkuExistsAsync(string sku, int? excludeId = null);
    Task AddAsync(Product product);
    Task SaveChangesAsync();
}
