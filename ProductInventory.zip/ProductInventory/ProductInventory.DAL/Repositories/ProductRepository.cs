using Microsoft.EntityFrameworkCore;
using ProductInventory.DAL.Entities;
namespace ProductInventory.DAL.Repositories;
public class ProductRepository : IProductRepository
{
    private readonly AppDbContext _db;
    public ProductRepository(AppDbContext db) => _db = db;

    public async Task<(List<Product> Items, int Total)> GetPagedAsync(string? search, ProductCategory? category, int? stockBelow, int page, int pageSize)
    {
        var q = _db.Products.AsNoTracking().Where(p => p.IsActive);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(p => p.Name.Contains(s) || p.Sku.Contains(s));
        }
        if (category.HasValue) q = q.Where(p => p.Category == category.Value);
        if (stockBelow.HasValue) q = q.Where(p => p.StockQuantity < stockBelow.Value);

        var total = await q.CountAsync();
        var items = await q.OrderBy(p => p.Id).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
        return (items, total);
    }

    public Task<Product?> GetByIdAsync(int id) => _db.Products.FirstOrDefaultAsync(p => p.Id == id);

    public Task<bool> SkuExistsAsync(string sku, int? excludeId = null)
        => _db.Products.AnyAsync(p => p.Sku == sku && (excludeId == null || p.Id != excludeId));

    public async Task AddAsync(Product product) => await _db.Products.AddAsync(product);
    public Task SaveChangesAsync() => _db.SaveChangesAsync();
}
