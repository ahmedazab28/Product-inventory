using ProductInventory.BLL.ViewModels;
using ProductInventory.DAL.Entities;
namespace ProductInventory.BLL.Services;
public interface IProductService
{
    Task<ProductListViewModel> GetListAsync(string? search, ProductCategory? category, bool lowStock, int page, int pageSize);
    Task<ProductViewModel?> GetByIdAsync(int id);
    Task<ServiceResult> CreateAsync(ProductViewModel vm);
    Task<ServiceResult> UpdateAsync(ProductViewModel vm);
    Task<ServiceResult> DeleteAsync(int id);              // soft delete
    Task<RestockViewModel?> GetRestockAsync(int id);
    Task<ServiceResult> RestockAsync(RestockViewModel vm);
}
