namespace ProductInventory.BLL.Services;
public class ServiceResult
{
    public bool Success => !NotFound && Errors.Count == 0;
    public bool NotFound { get; private set; }
    public List<(string Key, string Message)> Errors { get; } = new();
    public static ServiceResult Ok() => new();
    public static ServiceResult NotFoundResult() => new() { NotFound = true };
    public static ServiceResult Fail(string key, string message)
    { var r = new ServiceResult(); r.Errors.Add((key, message)); return r; }
}
