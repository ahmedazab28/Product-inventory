using Microsoft.EntityFrameworkCore;
using ProductInventory.BLL.ViewModels;
using ProductInventory.DAL.Entities;
using ProductInventory.DAL.Repositories;
namespace ProductInventory.BLL.Services;

public class ProductService : IProductService
{
    private const int LowStockThreshold = 5;
    private const string SkuExistsMsg = "A product with this SKU already exists";
    private readonly IProductRepository _repo;
    public ProductService(IProductRepository repo) => _repo = repo;

    public async Task<ProductListViewModel> GetListAsync(string? search, ProductCategory? category, bool lowStock, int page, int pageSize)
    {
        page = Math.Max(1, page);
        var (items, total) = await _repo.GetPagedAsync(search, category, lowStock ? LowStockThreshold : null, page, pageSize);
        return new ProductListViewModel
        {
            Items = items.Select(ToVm).ToList(),
            Page = page, PageSize = pageSize, TotalCount = total,
            Search = search, Category = category, LowStock = lowStock
        };
    }

    public async Task<ProductViewModel?> GetByIdAsync(int id)
    {
        var p = await _repo.GetByIdAsync(id);
        return p is { IsActive: true } ? ToVm(p) : null;
    }

    public async Task<ServiceResult> CreateAsync(ProductViewModel vm)
    {
        vm.Sku = vm.Sku.Trim().ToUpperInvariant();
        if (await _repo.SkuExistsAsync(vm.Sku))
            return ServiceResult.Fail(nameof(vm.Sku), SkuExistsMsg);

        var p = new Product { CreatedAt = DateTime.UtcNow, IsActive = true };
        Apply(p, vm);
        await _repo.AddAsync(p);
        return await SaveAsync();
    }

    public async Task<ServiceResult> UpdateAsync(ProductViewModel vm)
    {
        var p = await _repo.GetByIdAsync(vm.Id);
        if (p is not { IsActive: true }) return ServiceResult.NotFoundResult();

        vm.Sku = vm.Sku.Trim().ToUpperInvariant();
        if (await _repo.SkuExistsAsync(vm.Sku, vm.Id))
            return ServiceResult.Fail(nameof(vm.Sku), SkuExistsMsg);

        Apply(p, vm);
        return await SaveAsync();
    }

    public async Task<ServiceResult> DeleteAsync(int id)
    {
        var p = await _repo.GetByIdAsync(id);
        if (p is not { IsActive: true }) return ServiceResult.NotFoundResult();
        p.IsActive = false; // soft delete
        return await SaveAsync();
    }

    public async Task<RestockViewModel?> GetRestockAsync(int id)
    {
        var p = await _repo.GetByIdAsync(id);
        return p is { IsActive: true } ? new RestockViewModel { Id = p.Id, Name = p.Name, CurrentStock = p.StockQuantity } : null;
    }

    public async Task<ServiceResult> RestockAsync(RestockViewModel vm)
    {
        if (vm.Quantity <= 0)
            return ServiceResult.Fail(nameof(vm.Quantity), "Quantity must be greater than 0");
        var p = await _repo.GetByIdAsync(vm.Id);
        if (p is not { IsActive: true }) return ServiceResult.NotFoundResult();
        p.StockQuantity += vm.Quantity;
        return await SaveAsync();
    }

    private async Task<ServiceResult> SaveAsync()
    {
        try { await _repo.SaveChangesAsync(); return ServiceResult.Ok(); }
        catch (DbUpdateException) // race condition on the unique SKU index
        { return ServiceResult.Fail("Sku", SkuExistsMsg); }
    }

    private static void Apply(Product p, ProductViewModel vm)
    {
        p.Name = vm.Name.Trim();
        p.Sku = vm.Sku;
        p.Description = string.IsNullOrWhiteSpace(vm.Description) ? null : vm.Description.Trim();
        p.Price = vm.Price;
        p.StockQuantity = vm.StockQuantity;
        p.Category = vm.Category;
        p.ExpiryDate = vm.ExpiryDate;
    }

    private static ProductViewModel ToVm(Product p) => new()
    {
        Id = p.Id, Name = p.Name, Sku = p.Sku, Description = p.Description, Price = p.Price,
        StockQuantity = p.StockQuantity, Category = p.Category, IsActive = p.IsActive,
        CreatedAt = p.CreatedAt, ExpiryDate = p.ExpiryDate
    };
}
