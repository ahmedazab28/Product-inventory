using System.ComponentModel.DataAnnotations;
using ProductInventory.DAL.Entities;
namespace ProductInventory.BLL.ViewModels;

public class ProductViewModel : IValidatableObject
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Name is required")]
    [StringLength(100, ErrorMessage = "Name cannot exceed 100 characters")]
    public string Name { get; set; } = string.Empty;

    [Required(ErrorMessage = "SKU is required")]
    [StringLength(20, ErrorMessage = "SKU cannot exceed 20 characters")]
    public string Sku { get; set; } = string.Empty;

    [StringLength(500, ErrorMessage = "Description cannot exceed 500 characters")]
    public string? Description { get; set; }

    [Range(typeof(decimal), "0.01", "9999999999999999.99", ErrorMessage = "Price must be greater than 0")]
    public decimal Price { get; set; }

    [Range(0, int.MaxValue, ErrorMessage = "Stock quantity cannot be negative")]
    [Display(Name = "Stock Quantity")]
    public int StockQuantity { get; set; }

    public ProductCategory Category { get; set; }

    [Display(Name = "Active")]
    public bool IsActive { get; set; } = true;

    [Display(Name = "Created At")]
    public DateTime CreatedAt { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Expiry Date")]
    public DateTime? ExpiryDate { get; set; }

    // Server-side rules (client-side equivalents are in _ProductForm.cshtml)
    public IEnumerable<ValidationResult> Validate(ValidationContext ctx)
    {
        if (ExpiryDate.HasValue && ExpiryDate.Value.Date < DateTime.Today)
            yield return new ValidationResult("Expiry date cannot be in the past", new[] { nameof(ExpiryDate) });

        if (Category == ProductCategory.Grocery && !ExpiryDate.HasValue)
            yield return new ValidationResult("Expiry date is required for Grocery products", new[] { nameof(ExpiryDate) });
    }
}
