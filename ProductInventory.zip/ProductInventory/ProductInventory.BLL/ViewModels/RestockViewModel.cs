using System.ComponentModel.DataAnnotations;
namespace ProductInventory.BLL.ViewModels;
public class RestockViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public int CurrentStock { get; set; }
    [Range(1, int.MaxValue, ErrorMessage = "Quantity must be greater than 0")]
    public int Quantity { get; set; }
}
