using ProductInventory.DAL.Entities;
namespace ProductInventory.BLL.ViewModels;
public class ProductListViewModel
{
    public List<ProductViewModel> Items { get; set; } = new();
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 5;
    public int TotalCount { get; set; }
    public int TotalPages => (int)Math.Ceiling(TotalCount / (double)PageSize);
    public string? Search { get; set; }
    public ProductCategory? Category { get; set; }
    public bool LowStock { get; set; }
}
